extends Node2D

func _on_firstButton_pressed() -> void:
	get_tree().change_scene_to_file("res://src/Levels/LevelTemplate.tscn")


func _on_secondButton_pressed() -> void:
	get_tree().change_scene_to_file("res://src/Levels/Level2.tscn")\
