@tool
extends Area2D

@onready var anim_player: AnimationPlayer = get_node("AnimationPlayer")


func _on_body_entered(_body: Node) -> void:
	teleport()


func teleport() -> void:
	anim_player.play("fade _in")
	await anim_player.animation_finished
	get_tree().change_scene_to_file("res://src/Levels/LevelSelections.tscn")
