extends Node

var total_coin = 0
var player_lives = 3

func spawn_beer_bottle(pos):
	var BeerBottleScene = load("res://src/Objects/bottle.tscn")
	var beer_bottle = BeerBottleScene.instantiate()
	beer_bottle.global_position = pos
	get_tree().root.add_child(beer_bottle)
