extends CharacterBody2D

var speed = 30
var direction = 1
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
var velocity = Vector2.ZERO

func _physics_process(delta: float) -> void:
	velocity.y += gravity * delta
	velocity.x = speed
	set_velocity(velocity)
	set_up_direction(Vector2.UP)
	move_and_slide()
	velocity = velocity
	

func _on_area_2d_body_entered(body):
	if body.is_in_group("Player"):
		queue_free()
	else:
		direction *= -1
