extends CanvasLayer

func _ready() -> void:
	get_tree().paused = true

func _on_ContinueBtn_pressed() -> void:
	get_tree().paused = false
	queue_free()


func _on_MainMenuBtn_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://ui/MainMenuScreen.tscn")

