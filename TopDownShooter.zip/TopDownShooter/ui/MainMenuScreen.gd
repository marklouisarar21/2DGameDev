extends CanvasLayer




func _on_PlayBtn_pressed() -> void:
	get_tree().change_scene_to_file("res://Main.tscn")
	


func _on_QuitBtn_pressed() -> void:
	get_tree().quit()
