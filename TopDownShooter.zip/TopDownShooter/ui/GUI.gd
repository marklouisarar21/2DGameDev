extends CanvasLayer

@onready var health_bar = get_node("MarginContainer/Rows/TopRow/HealthBarSection/HealthBar")
@onready var current_ammo = get_node("MarginContainer/Rows/TopRow/AmmoSection/CurrentAmmo")
@onready var max_ammo = get_node("MarginContainer/Rows/TopRow/AmmoSection/MaxAmmo")
@onready var health_tween = get_node("MarginContainer/Rows/TopRow/HealthBarSection/Tween")

var player: Player

func set_player(player: Player):
	self.player = player
	
	set_new_health_value(player.health_stats.health)
	player.connect("player_health_changed", Callable(self, "set_new_health_value"))

	set_weapon(player.weapon_manager.get_current_weapon())
	player.weapon_manager.connect("weapon_changed", Callable(self, "set_weapon"))

func set_weapon(weapon: Weapon):
	set_current_ammo(weapon.current_ammo)
	set_max_ammo(weapon.max_ammo)
	if not weapon.is_connected("weapon_ammo_changed", Callable(self, "set_current_ammo")):
		weapon.connect("weapon_ammo_changed", Callable(self, "set_current_ammo"))


func set_new_health_value(new_health: int):
	var orig_color = Color("#17a034")
	var lowlife_color = Color("#c01717")
	var bar_style = health_bar.get("theme_override_styles/fg")
	health_tween.interpolate_property(health_bar, "value", health_bar.value, new_health, 0.4, Tween.TRANS_LINEAR, Tween.EASE_IN)
	health_tween.interpolate_property(bar_style, "bg_color", orig_color, lowlife_color, 0.2, Tween.TRANS_LINEAR, Tween.EASE_IN)
	health_tween.interpolate_property(bar_style, "bg_color", lowlife_color, orig_color, 0.2, Tween.TRANS_LINEAR, Tween.EASE_OUT, 0.2)
	health_tween.start()


func set_current_ammo(new_ammo: int):
	current_ammo.text = str(new_ammo)


func set_max_ammo(new_max_ammo: int):
	max_ammo.text = str(new_max_ammo)

