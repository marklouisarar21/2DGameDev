extends CanvasLayer

@onready var title = get_node("PanelContainer/MarginContainer/Rows/Title")
@onready var animation_player = get_node("AnimationPlayer")

func _ready() -> void:
	animation_player.play("fade")

func set_title(win: bool):
	if win:
		title.text = "YOU WIN!"
		title.modulate = Color.GREEN
	else:
		title.text = "YOU LOSE!"
		title.modulate = Color.RED

func _on_RestartBtn_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://Main.tscn")


func _on_QuitBtn_pressed() -> void:
	get_tree().quit()


func _on_MainMenuButton_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://ui/MainMenuScreen.tscn")
