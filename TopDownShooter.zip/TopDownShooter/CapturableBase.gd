extends Area2D
class_name CapturableBase

signal based_captured(new_team)


@export var neutral_color: Color = Color(1, 1, 1)
@export var player_color: Color = Color(0.196078, 0.392157, 0.196078)
@export var enemy_color: Color = Color(0.423529, 0.74902, 0.87451)

var player_unit_count: int = 0
var enemy_unit_count: int = 0
var team_to_capture: int = Team.TeamName.NEUTRAL

@onready var collision_shape = get_node("CollisionShape2D")
@onready var team = get_node("Team")
@onready var capture_timer = get_node("CaptureTimer")
@onready var sprite = get_node("Sprite2D")
@onready var player_label = get_node("PlayerLabel")
@onready var enemy_label = get_node("EnemyLabel")


func get_random_position_within_capture_radius() -> Vector2:
	var extents = collision_shape.shape.extents
	var top_left = collision_shape.global_position - (extents / 2)
	
	var x = randf_range(top_left.x, top_left.x + extents.x)
	var y = randf_range(top_left.y, top_left.y + extents.y)
	
	return Vector2(x, y)


func _on_CapturableBase_body_entered(_body: Node) -> void:
	if _body.has_method("get_team"):
		var body_team = _body.get_team()
		
		if body_team == Team.TeamName.ENEMY:
			enemy_unit_count += 1
			get_capturable_number()
		elif body_team == Team.TeamName.PLAYER:
			player_unit_count += 1
			get_capturable_number()
			
		check_whether_base_can_be_captured()


func _on_CapturableBase_body_exited(_body: Node) -> void:
	if _body.has_method("get_team"):
		var _body_team = _body.get_team()
		
		if _body_team == Team.TeamName.ENEMY:
			enemy_unit_count -= 1
		elif _body_team == Team.TeamName.PLAYER:
			player_unit_count -= 1
			
		check_whether_base_can_be_captured()


func check_whether_base_can_be_captured():
	var majority_team = get_team_with_majority()
	
	if majority_team == Team.TeamName.NEUTRAL:
		return
	elif majority_team == team.team:
		print("Owning team regained majority, stopping capture clock")
		team_to_capture = Team.TeamName.NEUTRAL
		capture_timer.stop()
	else:
		print("New team has majority in base, starting capture clock")
		team_to_capture = majority_team
		capture_timer.start()

func get_capturable_number():
	player_label.text = str(player_unit_count)
	enemy_label.text = str(enemy_unit_count)

func get_team_with_majority() -> int:

	if enemy_unit_count == player_unit_count:
		return Team.TeamName.NEUTRAL
	elif enemy_unit_count > player_unit_count:
		return Team.TeamName.ENEMY
	else:
		return Team.TeamName.PLAYER
	
func set_team(new_team: int):
	team.team = new_team
	emit_signal("based_captured", new_team)
	match new_team:
		Team.TeamName.NEUTRAL:
			sprite.modulate = neutral_color
			return
		Team.TeamName.PLAYER:
			sprite.modulate = player_color
			return
		Team.TeamName.ENEMY:
			sprite.modulate = enemy_color
			return

func _on_CaptureTimer_timeout() -> void:
	set_team(team_to_capture)
