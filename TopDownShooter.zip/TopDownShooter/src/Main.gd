extends Node2D

const Player = preload("res://src/Actor/Player.tscn")
const GameOverScreen = preload("res://ui/GameOverScreen.tscn")
const PauseScreen = preload("res://ui/PauseScreen.tscn")
const Shop = preload("res://src/Weapons/WeaponShop.tscn")


@onready var capturable_base_manager = get_node("CapturableBaseManager")
@onready var ally_ai = get_node("AllyMapAI")
@onready var enemy_ai = get_node("EnemyMapAI")
@onready var bullet_manager = get_node("BulletManager")
@onready var camera = get_node("Camera2D")
@onready var gui = get_node("GUI")
@onready var ground = get_node("Ground")
@onready var pathfinding = get_node("Pathfinding")

var shop_instance = null

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	randomize()
	GlobalSignals.connect("bullet_fired", Callable(bullet_manager, "handle_bullet_spawned"))
	
	var ally_respawns = get_node("AllyRespawnPoints")
	var enemy_respawns = get_node("EnemyRespawnPoints")
	
	
	pathfinding.create_navigation_map(ground)
	
	var bases = capturable_base_manager.get_capturable_bases()
	ally_ai.initialize(bases, ally_respawns.get_children(), pathfinding)
	enemy_ai.initialize(bases, enemy_respawns.get_children(), pathfinding)
	capturable_base_manager.connect("player_captured_all_bases", Callable(self, "handle_player_win"))
	capturable_base_manager.connect("player_lost_all_bases", Callable(self, "handle_player_lost"))
	
	
	spawn_player()

func spawn_player():
	var player = Player.instantiate()
	add_child(player)
	player.set_camera_transform(camera.get_path())
	player.connect("died", Callable(self, "spawn_player"))
	gui.set_new_health_value(player.health_stats.health)
	gui.set_player(player)

func handle_player_win():
	var game_over = GameOverScreen.instantiate()
	add_child(game_over)
	game_over.set_title(true)
	get_tree().paused = true

func handle_player_lost():
	var game_over = GameOverScreen.instantiate()
	add_child(game_over)
	game_over.set_title(false)
	get_tree().paused = true

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		var paused_scr = PauseScreen.instantiate()
		add_child(paused_scr)
	
	if event.is_action_pressed("shop"):
		toggle_shop()

func toggle_shop():
	if shop_instance == null:
		# The shop is not open, so open it
		shop_instance = Shop.instance()
		add_child(shop_instance)
		shop_instance.connect("buy_weapon", Callable(self, "_on_buy_weapon"))
	else:
		# If the shop instance is already open then it close.
		shop_instance.queue_free()
		shop_instance = null

func _on_buy_weapon(_weapon: PackedScene):
	add_child(_weapon.instantiate())
