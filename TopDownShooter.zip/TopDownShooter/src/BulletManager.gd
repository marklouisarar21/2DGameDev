extends Node2D


func handle_bullet_spawned(bullet, team: int, position, direction):
	add_child(bullet)
	bullet.team = team
	bullet.global_position = position
	bullet.set_direction(direction)
	
