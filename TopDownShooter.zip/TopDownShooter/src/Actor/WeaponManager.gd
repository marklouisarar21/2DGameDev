extends Node2D
class_name weapon_manager

signal weapon_changed(new_weapon)

@onready var current_weapon: Weapon = get_node("Pistol") # Hold the currently equipped weapon
var weapons: Array = []  # List of weapon scenes available to the player (this is optional)

func _ready() -> void:
	# Populate weapons array with child nodes of the WeaponManager
	weapons = get_children()
	
	# Initially hide all weapons
	for weapon in weapons:
		weapon.hide()

	# Show the default weapon if any (we'll handle equipping a new one)
	if current_weapon:
		current_weapon.show()

func _process(delta: float) -> void:
	# Logic to shoot, etc. (this can stay as is)
	if current_weapon and not current_weapon.semi_auto and Input.is_action_just_pressed("shoot"):
		current_weapon.shoot()

func initialize(team: int) -> void:
	# Initialize all weapons (if needed for things like ammo, team affiliation)
	for weapon in weapons:
		weapon.initialize(team)

func get_current_weapon() -> Weapon:
	# Return the current weapon being used
	return current_weapon

func switch_weapon(weapon: Weapon):
	# Handle switching weapons, if that's part of the control scheme
	if weapon == current_weapon:
		return
	
	current_weapon.hide()
	weapon.show()
	current_weapon = weapon
	emit_signal("weapon_changed", current_weapon)

func reload():
	# Call reload function for the current weapon
	if current_weapon:
		current_weapon.start_reload()

# Handle input events (you might have already handled this for switching between weapons, etc.)
func _unhandled_input(event: InputEvent) -> void:
	if current_weapon and current_weapon.semi_auto and event.is_action_released("shoot"):
		current_weapon.shoot()
	elif event.is_action_released("reload"):
		reload()
	elif event.is_action_released("weapon_1"):
		switch_weapon(weapons[0])
	elif event.is_action_released("weapon_2"):
		switch_weapon(weapons[1])
	elif event.is_action_released("weapon_3"):
		switch_weapon(weapons[2])
	elif event.is_action_released("weapon_4"):
		switch_weapon(weapons[3])
	
