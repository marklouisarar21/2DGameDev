extends CharacterBody2D
class_name Player

signal player_health_changed(new_health)
signal died

@export var speed: int = 150

@onready var collision_shape = get_node("CollisionShape2D")
@onready var health_stats = get_node("Health")
@onready var weapon_manager = get_node("WeaponManager")
@onready var team = get_node("Team")
@onready var camera_transform = get_node("CameraTransform")


func _ready() -> void:
	weapon_manager.initialize(team.team)


func _physics_process(delta: float) -> void:
	var movement_direction := Vector2.ZERO
	
	if Input.is_action_pressed("up"):
		movement_direction.y = -1
	if Input.is_action_pressed("down"):
		movement_direction.y = 1
	if Input.is_action_pressed("left"):
		movement_direction.x = -1
	if Input.is_action_pressed("right"):
		movement_direction.x = 1
	
	movement_direction = movement_direction.normalized()
	set_velocity(movement_direction * speed)
	move_and_slide()
	
	look_at(get_global_mouse_position())


func set_camera_transform(camera_path: NodePath):
	camera_transform.remote_path = camera_path

func get_team() -> int:
	return team.team
		
func shoot(bullet_instance, location: Vector2, direction: Vector2):
	GlobalSignals.emit_signal("bullet_fired", bullet_instance, location, direction)


func handle_hit():
	health_stats.health -= 20
	emit_signal("player_health_changed", health_stats.health)
	if health_stats.health <= 0:
		die()
		get_tree().change_scene_to_file("res://ui/GameOverScreen.tscn")

func die():
	emit_signal("died")
	queue_free()

# Method to change the weapon from shop purchase
func change_weapon(new_weapon_scene: PackedScene):
	if new_weapon_scene == null:
		push_error("❌ Weapon scene is null in change_weapon!")
		return
	
	var new_weapon = new_weapon_scene.instantiate()
	weapon_manager.switch_weapon(new_weapon)
