extends CharacterBody2D
class_name Actor

signal died

@onready var collision_shape = get_node("CollisionShape2D")
@onready var health_stats = get_node("Health")
@onready var ai = get_node("AI")
@onready var weapon: Weapon = get_node("Weapon")
@onready var team = get_node("Team")

@export var speed: int = 150


func _ready() -> void:
	ai.initialize(self, weapon, team.team)
	weapon.initialize(team.team)


func rotate_toward(location: Vector2):
	rotation = lerp_angle(rotation, global_position.direction_to(location).angle(), 0.1)


func velocity_toward(location: Vector2) -> Vector2:
	return global_position.direction_to(location) * speed

func has_reached_position(location: Vector2) -> bool:
	return global_position.distance_to(location) < 5

func get_team() -> int:
	return team.team

func handle_hit():
	health_stats.health -= 20
	if health_stats.health <= 0:
		die()

func die():
	emit_signal("died")
	queue_free()
