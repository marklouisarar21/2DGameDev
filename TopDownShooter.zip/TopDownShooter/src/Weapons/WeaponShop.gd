extends CanvasLayer

signal buy_weapon

var player: Player = null
var selected_weapon: PackedScene = null  # Weapon chosen in the shop

func _ready():
	var player = null
	self.player = player
	player = get_tree().get_root().find_child("Player", true, false)
	if not player:
		push_error("❌ Player not found in scene tree!")

	# Bind the button to handle weapon purchase
	var mgn = get_node("CenterContainer/PanelContainer/VBoxContainer/HBoxContainer/MachineGun/HBoxContainer/MarginContainer2/VBoxContainer/Button")
	if not mgn.is_connected("pressed", Callable(self, "_on_buy_machinegun_pressed")):
		mgn.connect("pressed", Callable(self, "_on_buy_machinegun_pressed"))

	var granade_launcher = get_node("CenterContainer/PanelContainer/VBoxContainer/HBoxContainer/GranadeLauncher/HBoxContainer/MarginContainer2/VBoxContainer/Button")
	if not granade_launcher.is_connected("pressed", Callable(self, "_on_buy_granadelauncher_pressed")):
		granade_launcher.connect("pressed", Callable(self, "_on_buy_granadelauncher_pressed"))

	var sniper = get_node("CenterContainer/PanelContainer/VBoxContainer/HBoxContainer/Sniper/HBoxContainer/MarginContainer2/VBoxContainer/Button")
	if not sniper.is_connected("pressed", Callable(self, "_on_buy_sniper_pressed")):
		sniper.connect("pressed", Callable(self, "_on_buy_sniper_pressed"))

func _on_buy_machinegun_pressed() -> void:
	selected_weapon = preload("res://src/Weapons/MachineGunWeapon.tscn")
	emit_signal("buy_weapon", selected_weapon)
#	if player:
#		player.change_weapon(selected_weapon)
#	else:
#		push_error("❌ Player is not set in Shop script!")
#	queue_free()  # Optionally hide or close the shop UI after purchase


func _on_granadelauncher_pressed() -> void:
	print("Granade Launcher Bought!")


func _on_sniper_pressed() -> void:
	print("Sniper Bought!")
