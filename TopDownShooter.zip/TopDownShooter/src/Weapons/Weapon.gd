extends Node2D
class_name Weapon

signal weapon_ammo_changed(new_ammo_count)
signal weapon_out_of_ammo


@export var Bullet: PackedScene
@export var max_ammo: int = 10
@export var semi_auto := true


var current_ammo: int = max_ammo: set = set_current_ammo

var team: int = -1

@onready var end_of_gun = get_node("EndOfGun")
@onready var attack_cooldown = get_node("AttackCooldown")
@onready var animation_player = get_node("AnimationPlayer")
@onready var muzzleflash = get_node("MuzzleFlash")
@onready var gun_shoot = get_node("AudioStreamPlayer2D")
@onready var sound_timer = get_node("guntimer")
@onready var reload_gun = get_node("reload_gun")
@onready var reload_cooldown = get_node("Reload_cd")

func _ready() -> void:
	muzzleflash.hide()
	current_ammo = max_ammo


func initialize(team: int):
	self.team = team

func start_reload():
	animation_player.play("reload")
	reload_cooldown.start()
	reload_gun.play()
	
func _stop_reload():
	current_ammo = max_ammo
	emit_signal("weapon_ammo_changed", current_ammo)


func set_current_ammo(new_ammo: int):
	var actual_ammo = clamp(new_ammo, 0, max_ammo)
	if actual_ammo != current_ammo:
		current_ammo = actual_ammo
		if current_ammo == 0:
			emit_signal("weapon_out_of_ammo")
			
		emit_signal("weapon_ammo_changed", current_ammo)


func shoot():
	if current_ammo != 0 and attack_cooldown.is_stopped() and Bullet != null:
		var bullet_instance = Bullet.instance()
		var direction = (end_of_gun.global_position - global_position).normalized()
		GlobalSignals.emit_signal("bullet_fired", bullet_instance, team, end_of_gun.global_position, direction)
		attack_cooldown.start()
		sound_timer.start()
		gun_shoot.play()
		animation_player.play("muzzle_flash")
		set_current_ammo(current_ammo - 1)


func _on_guntimer_timeout() -> void:
	gun_shoot.stop()


func _on_Reload_cd_timeout() -> void:
	reload_gun.stop()
