extends Area2D
class_name Bullet

@export var speed: int = 10

@onready var kill_timer = get_node("KillTimer")
var direction := Vector2.ZERO
var team: int = -1

func _ready() -> void:
	kill_timer.start()
	
func _physics_process(delta: float) -> void:
	if direction != Vector2.ZERO:
		var velocity = direction * speed
		global_position += velocity

func set_direction(direction: Vector2):
	self.direction = direction
	rotation += direction.angle()


func _on_KillTimer_timeout() -> void:
	queue_free()


func _on_Bullet_body_entered(_body: Node) -> void:
	if _body.has_method("handle_hit"):
		GlobalSignals.emit_signal("bullet_impacted", _body.global_position, direction)
		if _body.has_method("get_team") and _body.get_team() != team:
			_body.handle_hit()
	queue_free()
